let hours_worked_gloria = -1
let hours_worked_alisha = -1
let hours_worked_evelyn = -1
